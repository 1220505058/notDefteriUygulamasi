
class GuncellenmisNot implements NotDurumu {
    @Override
    public void durumBilgisi() {
        System.out.println("Bu not güncellendi.");
    }
}
