
class SilinmisNot implements NotDurumu {
    @Override
    public void durumBilgisi() {
        System.out.println("Bu not silindi.");
    }
}
