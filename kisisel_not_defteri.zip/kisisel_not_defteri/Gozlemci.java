
interface Gozlemci {
    void guncelle(String mesaj);
}
