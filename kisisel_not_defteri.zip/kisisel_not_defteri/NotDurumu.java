
interface NotDurumu {
    void durumBilgisi();
}
